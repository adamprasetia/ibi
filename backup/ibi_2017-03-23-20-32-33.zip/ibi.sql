#
# TABLE STRUCTURE FOR: bidan
#

DROP TABLE IF EXISTS `bidan`;

CREATE TABLE `bidan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomor` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat_rumah` text NOT NULL,
  `alamat_praktik` text NOT NULL,
  `tlp` varchar(20) NOT NULL,
  `golongan_darah` int(11) NOT NULL,
  `pendidikan` int(11) NOT NULL,
  `kampus` varchar(50) NOT NULL,
  `tahun_lulus` varchar(4) NOT NULL,
  `no_ijazah` varchar(50) NOT NULL,
  `tempat_kerja` varchar(100) NOT NULL,
  `status_pegawai` int(11) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pendidikan` (`pendidikan`),
  KEY `status_kepegawaian` (`status_pegawai`),
  KEY `golongan_darah` (`golongan_darah`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'IBI-00001', 'Adam Prasetia', 'Bandung', '1989-02-16', 'Cianjur', 'Jakarta', '083817321885', '2', '7', 'Universitas Suryakancana Cianjur', '2011', '', 'PT Kompas Cyber Media', '1', '033152', '1', '2017-03-20 18:58:22', '1', '2017-03-21 23:51:44');
INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'IBI-00002', 'Ulfah Awaliah', 'Cianjur', '1990-12-04', 'warujajar', 'Cilaku', '083817321712', '3', '7', '', '', '', '', '0', '', '1', '2017-03-20 19:13:02', '1', '2017-03-21 23:51:34');
INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', 'IBI-00003', 'Ulfi Alawiyah', 'Cianjur', '0000-00-00', '', '', '', '0', '0', '', '', '', '', '0', '', '1', '2017-03-22 22:05:51', '1', '2017-03-23 00:47:57');
INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', 'IBI-00004', 'Fabian Musa Azzaky', 'Cianjur', '2016-02-09', '', '', '', '0', '0', '', '', '', '', '0', '', '1', '2017-03-22 22:06:00', '1', '2017-03-22 23:57:54');
INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', 'IBI-00005', 'Mayang Arum Sari', '', '0000-00-00', '', '', '', '0', '0', '', '', '', '', '0', '', '1', '2017-03-22 22:06:12', '1', '2017-03-23 00:08:40');
INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('9', 'IBI-00006', 'Fida Rahma', 'Cianjur', '1949-03-16', '', '', '', '0', '0', '', '', '', '', '0', '', '1', '2017-03-23 00:10:15', '1', '2017-03-23 00:42:44');
INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('10', 'IBI-00007', 'Ronaldo', 'Portugal', '1975-03-12', '', '', '', '0', '0', '', '', '', '', '0', '', '1', '2017-03-23 00:10:30', '1', '2017-03-23 00:40:29');
INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('11', 'IBI-00008', 'Dedi Ahdiat', '', '0000-00-00', '', '', '', '0', '0', '', '', '', '', '0', '', '1', '2017-03-23 00:41:35', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan` (`id`, `nomor`, `name`, `tempat_lahir`, `tanggal_lahir`, `alamat_rumah`, `alamat_praktik`, `tlp`, `golongan_darah`, `pendidikan`, `kampus`, `tahun_lulus`, `no_ijazah`, `tempat_kerja`, `status_pegawai`, `nip`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('12', 'IBI-00009', 'Dwi Windari Endah Suci Rahayu', '', '0000-00-00', '', '', '', '0', '0', '', '', '', '', '0', '', '1', '2017-03-23 00:41:48', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bidan_kta
#

DROP TABLE IF EXISTS `bidan_kta`;

CREATE TABLE `bidan_kta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `bidan` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `attachment` varchar(50) NOT NULL,
  `nomor` varchar(20) NOT NULL,
  `masa_berlaku` date NOT NULL,
  `status` int(11) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bidan` (`bidan`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('17', '2017-03-22', '4', '2', '1,2,3,4', '12312323', '2017-03-25', '1', '1', '2017-03-20 23:03:21', '1', '2017-03-22 21:37:23');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('18', '2017-03-20', '5', '1', '1,2,3,4', '09020202', '2017-03-08', '2', '1', '2017-03-20 23:11:46', '1', '2017-03-22 22:43:11');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('20', '2017-03-21', '4', '2', '1,2,4', '78978797', '2017-02-01', '1', '1', '2017-03-21 22:50:26', '1', '2017-03-23 00:50:48');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('21', '0000-00-00', '5', '0', '', '', '0000-00-00', '0', '1', '2017-03-22 00:13:42', '1', '2017-03-22 00:15:00');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('22', '0000-00-00', '5', '0', '3', '', '0000-00-00', '0', '1', '2017-03-22 00:15:13', '1', '2017-03-22 00:15:25');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('23', '0000-00-00', '4', '0', '', '', '2017-03-30', '1', '1', '2017-03-22 21:39:59', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('24', '0000-00-00', '4', '0', '', '', '2017-05-04', '1', '1', '2017-03-22 21:40:19', '1', '2017-03-22 21:42:16');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('25', '0000-00-00', '7', '0', '', '', '2017-03-23', '1', '1', '2017-03-22 22:07:11', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('26', '0000-00-00', '7', '0', '', '', '2017-05-10', '1', '1', '2017-03-22 22:08:14', '1', '2017-03-22 22:16:07');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('27', '0000-00-00', '7', '0', '', '', '2017-03-20', '1', '1', '2017-03-22 22:08:25', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('28', '0000-00-00', '6', '0', '', '', '2017-04-19', '1', '1', '2017-03-22 22:16:29', '1', '2017-03-22 22:18:21');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('29', '0000-00-00', '8', '0', '', '', '2017-03-01', '1', '1', '2017-03-22 22:24:22', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('30', '2017-03-02', '8', '0', '', '', '2017-03-02', '1', '1', '2017-03-22 22:24:33', '1', '2017-03-22 22:24:45');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('31', '0000-00-00', '8', '0', '', '', '2017-01-04', '1', '1', '2017-03-22 22:27:26', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta` (`id`, `date`, `bidan`, `type`, `attachment`, `nomor`, `masa_berlaku`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('33', '2017-03-23', '10', '1', '1,2,3,4', '', '0000-00-00', '2', '1', '2017-03-23 00:41:02', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bidan_kta_attachment
#

DROP TABLE IF EXISTS `bidan_kta_attachment`;

CREATE TABLE `bidan_kta_attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bidan_kta_attachment` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'FOTO COPY STR YANG MASIH BERLAKU 1 LEMBAR', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta_attachment` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'FOTO COPY IJAZAH 1 LEMBAR', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta_attachment` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'FOTO UKURAN 3X4 (LATAR BELAKANG MERAH & MEMAKAI SERAGAM IBI) 1 LEMBAR', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta_attachment` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'FOTO COPY KTA LAMA 1 LEMBAR (BAGI PERPANJANGAN)', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bidan_kta_status
#

DROP TABLE IF EXISTS `bidan_kta_status`;

CREATE TABLE `bidan_kta_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bidan_kta_status` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Selesai', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta_status` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Sedang Di Proses', '0', '0000-00-00 00:00:00', '1', '2017-03-22 00:00:02');
INSERT INTO `bidan_kta_status` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Kurang Persyaratan', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta_status` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'Ditolak', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bidan_kta_type
#

DROP TABLE IF EXISTS `bidan_kta_type`;

CREATE TABLE `bidan_kta_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bidan_kta_type` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Pertama', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta_type` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Perpanjangan', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `bidan_kta_type` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Hilang', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bidan_pelatihan
#

DROP TABLE IF EXISTS `bidan_pelatihan`;

CREATE TABLE `bidan_pelatihan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bidan` int(11) NOT NULL,
  `pelatihan` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: bidan_sib
#

DROP TABLE IF EXISTS `bidan_sib`;

CREATE TABLE `bidan_sib` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bidan` int(11) NOT NULL,
  `nomor` varchar(20) NOT NULL,
  `masa_berlaku` date NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bidan_sib` (`id`, `bidan`, `nomor`, `masa_berlaku`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', '4', 'sib001', '2017-03-24', '1', '2017-03-20 18:58:22', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bidan_sipb_m
#

DROP TABLE IF EXISTS `bidan_sipb_m`;

CREATE TABLE `bidan_sipb_m` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bidan` int(11) NOT NULL,
  `nomor` varchar(20) NOT NULL,
  `nomor_rekomendasi` varchar(20) NOT NULL,
  `masa_berlaku` date NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bidan_sipb_m` (`id`, `bidan`, `nomor`, `nomor_rekomendasi`, `masa_berlaku`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', '4', 'sipb-m001', '', '2017-03-22', '1', '2017-03-20 18:58:22', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bidan_sipb_p
#

DROP TABLE IF EXISTS `bidan_sipb_p`;

CREATE TABLE `bidan_sipb_p` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bidan` int(11) NOT NULL,
  `nomor` varchar(20) NOT NULL,
  `nomor_rekomendasi` varchar(20) NOT NULL,
  `masa_berlaku` date NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bidan_sipb_p` (`id`, `bidan`, `nomor`, `nomor_rekomendasi`, `masa_berlaku`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', '4', 'sipb-p001', '', '2017-03-23', '1', '2017-03-20 18:58:22', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bidan_str
#

DROP TABLE IF EXISTS `bidan_str`;

CREATE TABLE `bidan_str` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bidan` int(11) NOT NULL,
  `nomor` varchar(20) NOT NULL,
  `masa_berlaku` date NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bidan_str` (`id`, `bidan`, `nomor`, `masa_berlaku`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', '4', 'str001', '2017-03-21', '1', '2017-03-20 18:58:22', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: golongan_darah
#

DROP TABLE IF EXISTS `golongan_darah`;

CREATE TABLE `golongan_darah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `golongan_darah` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'A', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `golongan_darah` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'B', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `golongan_darah` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'AB', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `golongan_darah` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'O', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: iuran
#

DROP TABLE IF EXISTS `iuran`;

CREATE TABLE `iuran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bidan` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: module
#

DROP TABLE IF EXISTS `module`;

CREATE TABLE `module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `url` varchar(50) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `parent` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Beranda', 'home', 'fa fa-home', '0', '1', '1', '2016-12-15 22:24:48', '1', '2016-12-15 23:23:09');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Data Master', '', 'fa fa-database', '0', '2', '1', '2016-12-15 22:25:55', '1', '2016-12-15 23:23:29');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('23', 'Level User', 'users_level', '', '2', '5', '1', '2016-12-15 23:12:35', '1', '2017-03-15 22:01:06');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('24', 'Status User', 'reference/users_status', '', '2', '6', '1', '2016-12-15 23:13:12', '1', '2017-03-15 22:01:17');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('25', 'Pengguna', 'users', 'fa fa-user', '0', '6', '1', '2016-12-15 23:15:54', '1', '2016-12-15 23:25:30');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('26', 'Backup', 'backup', 'fa fa-download', '0', '8', '1', '2016-12-15 23:16:42', '1', '2016-12-16 00:21:36');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('27', 'Module', 'module', 'fa fa-check', '0', '7', '1', '2016-12-16 00:21:22', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('37', 'Pendidikan', 'reference/pendidikan', '', '2', '2', '1', '2017-03-15 22:01:56', '1', '2017-03-15 22:14:37');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('38', 'Pelatihan', 'reference/pelatihan', '', '2', '2', '1', '2017-03-15 22:03:49', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('39', 'Status Kepegawaian', 'reference/status_pegawai', '', '2', '3', '1', '2017-03-15 22:04:16', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('40', 'Bidan', 'bidan', '', '2', '1', '1', '2017-03-15 22:14:17', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('41', 'Transaksi', '', 'fa fa-tasks', '0', '3', '1', '2017-03-21 20:23:07', '1', '2017-03-21 20:24:17');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('42', 'KTA', 'kta', '', '41', '1', '1', '2017-03-21 20:23:22', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('43', 'Golongan Darah', 'reference/golongan_darah', '', '2', '5', '1', '2017-03-21 23:56:30', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('44', 'Status KTA', 'reference/bidan_kta_status', '', '2', '6', '1', '2017-03-21 23:57:27', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('45', 'Tipe KTA', 'reference/bidan_kta_type', '', '2', '7', '1', '2017-03-21 23:57:51', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('46', 'Reminder', 'reminder', 'fa fa-bell', '0', '4', '1', '2017-03-22 21:02:53', '1', '2017-03-22 21:04:18');


#
# TABLE STRUCTURE FOR: pelatihan
#

DROP TABLE IF EXISTS `pelatihan`;

CREATE TABLE `pelatihan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `pelatihan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'APN', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pelatihan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'PONED', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pelatihan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'CTU', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pelatihan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'Management BBL', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pelatihan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'MU', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pelatihan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', 'ASFIKSI', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pelatihan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', 'KIP', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pelatihan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', 'ABPK', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: pendidikan
#

DROP TABLE IF EXISTS `pendidikan`;

CREATE TABLE `pendidikan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `pendidikan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'D3', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pendidikan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'D4', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pendidikan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'S1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pendidikan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'S2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `pendidikan` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'Lain-Lain', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: status_pegawai
#

DROP TABLE IF EXISTS `status_pegawai`;

CREATE TABLE `status_pegawai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `status_pegawai` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'PNS', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `status_pegawai` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'PTT Pusat', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `status_pegawai` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'PTT Provinsi', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `status_pegawai` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'PTT Daerah', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `status_pegawai` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'Magang', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `status_pegawai` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', 'TKS', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `status_pegawai` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', 'Assisten Bidan', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` int(11) NOT NULL,
  `ip_login` varchar(50) NOT NULL,
  `date_login` datetime NOT NULL,
  `user_agent` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `users` (`id`, `name`, `username`, `password`, `level`, `ip_login`, `date_login`, `user_agent`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Adam Prasetia', 'damz', '202cb962ac59075b964b07152d234b70', '1', '::1', '2017-03-23 20:26:36', 'Windows 7(Google Chrome 56.0.2924.87)', '1', '0', '0000-00-00 00:00:00', '2', '2016-10-21 09:34:23');
INSERT INTO `users` (`id`, `name`, `username`, `password`, `level`, `ip_login`, `date_login`, `user_agent`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Farida Ambarwati', 'ambar', 'caf1a3dfb505ffed0d024130f58c5cfa', '2', '::1', '2016-12-16 01:56:01', 'Windows 7(Google Chrome 55.0.2883.87)', '1', '1', '2016-10-21 09:21:00', '1', '2016-12-16 01:12:10');
INSERT INTO `users` (`id`, `name`, `username`, `password`, `level`, `ip_login`, `date_login`, `user_agent`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Budiarti', 'adhe', '202cb962ac59075b964b07152d234b70', '3', '::1', '2017-01-01 15:10:28', 'Windows 7(Google Chrome 55.0.2883.87)', '1', '1', '2016-12-30 20:17:58', '0', '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `name`, `username`, `password`, `level`, `ip_login`, `date_login`, `user_agent`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'Ulfi Alawiah', 'ulfi', '202cb962ac59075b964b07152d234b70', '1', '::1', '2017-03-23 19:44:07', 'Windows 7(Google Chrome 56.0.2924.87)', '1', '1', '2017-03-23 19:41:56', '1', '2017-03-23 19:42:12');


#
# TABLE STRUCTURE FOR: users_level
#

DROP TABLE IF EXISTS `users_level`;

CREATE TABLE `users_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `module` text NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `users_level` (`id`, `name`, `module`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'ADMIN', '1,2,40,37,38,39,23,43,24,44,45,41,42,46,25,27,26', '0', '0000-00-00 00:00:00', '4', '2017-03-23 19:52:02');


#
# TABLE STRUCTURE FOR: users_status
#

DROP TABLE IF EXISTS `users_status`;

CREATE TABLE `users_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `users_status` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'ACTIVE', '0', '2015-10-31 14:00:03', '1', '2016-06-24 10:43:51');
INSERT INTO `users_status` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'NOT ACTIVE', '0', '2015-10-31 14:00:03', '1', '2016-06-24 10:43:55');


