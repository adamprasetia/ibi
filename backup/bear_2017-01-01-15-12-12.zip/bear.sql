#
# TABLE STRUCTURE FOR: assets
#

DROP TABLE IF EXISTS `assets`;

CREATE TABLE `assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_entry` date NOT NULL,
  `description` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `note` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `assets` (`id`, `date_entry`, `description`, `qty`, `price`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', '2016-11-15', 'Monitor Viewsonic 16 Inc', '13', '845000', 'note aja', '1', '2016-11-15 13:28:02', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bank
#

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `rekening` varchar(50) NOT NULL,
  `cabang` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Bank BCA 1', '301-401-7700', 'Bendungan Hilir', '1', '2016-11-12 10:23:44', '1', '2016-11-12 10:25:49');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Bank BCA 2', '552-060-0177', 'Warung Buncit', '1', '2016-11-12 10:26:19', '0', '0000-00-00 00:00:00');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Bank Mega', '01-003-0011-00536-8', 'Bendungan Hilir', '1', '2016-11-12 10:26:53', '0', '0000-00-00 00:00:00');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'Bank BRI', '0206-01-003143-308', 'Bendungan Hilir', '1', '2016-11-12 10:27:23', '0', '0000-00-00 00:00:00');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'Bank Mandiri', '070-000-6258722', 'Warung Buncit', '1', '2016-11-12 10:28:01', '0', '0000-00-00 00:00:00');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', 'Bank Permata', '0', 'Glodok', '1', '2016-11-12 10:28:23', '0', '0000-00-00 00:00:00');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', 'Bank Bukopin', '100-107-2435', 'S Parman', '1', '2016-11-12 10:28:42', '0', '0000-00-00 00:00:00');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', 'Bank BNI 1', '02-042-94318', 'Senayan', '1', '2016-11-12 10:29:07', '0', '0000-00-00 00:00:00');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('9', 'Bank BNI 2', '02-059-10825', 'Senayan', '1', '2016-11-12 10:29:28', '0', '0000-00-00 00:00:00');
INSERT INTO `bank` (`id`, `name`, `rekening`, `cabang`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('10', 'Bank MNC', '100-01-0000-230761', 'MNC Tower', '1', '2016-11-12 10:29:54', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: bank_book
#

DROP TABLE IF EXISTS `bank_book`;

CREATE TABLE `bank_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` int(11) NOT NULL,
  `date_entry` date NOT NULL,
  `description` varchar(100) NOT NULL,
  `cek_no` varchar(50) NOT NULL,
  `crt2` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `bank_book` (`id`, `bank`, `date_entry`, `description`, `cek_no`, `crt2`, `total`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('12', '3', '2016-11-13', '', '', '1', '700000', '1', '2016-11-13 11:02:18', '0', '0000-00-00 00:00:00');
INSERT INTO `bank_book` (`id`, `bank`, `date_entry`, `description`, `cek_no`, `crt2`, `total`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('16', '2', '2016-11-22', '', '', '2', '1000000', '1', '2016-11-22 10:55:26', '0', '0000-00-00 00:00:00');
INSERT INTO `bank_book` (`id`, `bank`, `date_entry`, `description`, `cek_no`, `crt2`, `total`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('17', '2', '2016-11-23', '', '', '2', '1000000', '1', '2016-11-22 10:57:57', '0', '0000-00-00 00:00:00');
INSERT INTO `bank_book` (`id`, `bank`, `date_entry`, `description`, `cek_no`, `crt2`, `total`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('18', '1', '2016-12-30', 'Bunga bank', '', '1', '10000', '1', '2016-12-30 20:22:50', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: biaya
#

DROP TABLE IF EXISTS `biaya`;

CREATE TABLE `biaya` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `biaya` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Umum', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `biaya` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Project', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: big_cash
#

DROP TABLE IF EXISTS `big_cash`;

CREATE TABLE `big_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_entry` date NOT NULL,
  `crt2` int(11) NOT NULL,
  `voucher` int(11) NOT NULL,
  `posting` int(11) NOT NULL,
  `postingsub` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `received` varchar(50) NOT NULL,
  `bank` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `note` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `posting` (`posting`),
  KEY `bank` (`bank`),
  KEY `postingsub` (`postingsub`),
  KEY `crt2` (`crt2`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `big_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `bank`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', '2015-01-01', '1', '1', '1', '0', 'Terima Saldo awal Per Jan 2015', 'Ambar', '0', '217521329', 'Sebagai Saldo Awal Kas Besar Per 1 Jan 2015', '2', '2016-12-28 10:54:40', '2', '2016-12-28 11:08:22');
INSERT INTO `big_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `bank`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', '2015-01-02', '2', '1', '23', '0', 'Pembelian token listrik kantor mampang V (33.000) Per Jan 2015', 'PLN', '0', '3000000', '', '2', '2016-12-28 10:57:29', '0', '0000-00-00 00:00:00');
INSERT INTO `big_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `bank`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', '2015-01-02', '2', '2', '24', '0', 'Pembelian token listrik kantor mampang VIII (Periode Jan 2015 )', 'PLN', '0', '1000000', '', '2', '2016-12-28 11:00:35', '0', '0000-00-00 00:00:00');
INSERT INTO `big_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `bank`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', '2015-01-05', '2', '3', '29', '0', 'Petty Cash', 'adhe', '0', '2000000', '', '2', '2016-12-28 11:01:46', '0', '0000-00-00 00:00:00');
INSERT INTO `big_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `bank`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('9', '2015-01-07', '2', '4', '25', '0', 'Pembelian PSU,termal,memory,service mainboard', 'Fardha', '0', '1850000', '', '2', '2016-12-28 11:03:33', '0', '0000-00-00 00:00:00');
INSERT INTO `big_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `bank`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('10', '2015-01-09', '2', '5', '14', '0', 'Pengiriman Mercindise Kaos dan sarung tangan HM Sampoerna by JNE', 'JNE', '0', '230200', '', '2', '2016-12-28 11:14:56', '0', '0000-00-00 00:00:00');
INSERT INTO `big_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `bank`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('11', '2015-01-09', '2', '6', '28', '3', 'Pembayaran Pajak PPh Pasal 21 Karyawan Per Dec 2014', 'Pajak', '0', '1834018', '', '2', '2016-12-28 11:17:24', '0', '0000-00-00 00:00:00');
INSERT INTO `big_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `bank`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('12', '2014-10-15', '2', '7', '28', '4', 'Pembayaran Pajak PPh Pasal 25 / 29 Badan Periode Dec 2014', 'Pajak', '0', '2498959', '', '2', '2016-12-28 11:19:21', '1', '2016-12-31 15:08:22');


#
# TABLE STRUCTURE FOR: client
#

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `client` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'PT BNI', '1', '2016-11-15 09:04:28', '0', '0000-00-00 00:00:00');
INSERT INTO `client` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'PT BRI', '1', '2016-11-15 09:04:40', '0', '0000-00-00 00:00:00');
INSERT INTO `client` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'PT HM SAMPOERNA', '1', '2016-11-15 09:04:53', '0', '0000-00-00 00:00:00');
INSERT INTO `client` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', 'PT BANK BUKOPIN', '1', '2016-11-15 09:05:00', '0', '0000-00-00 00:00:00');
INSERT INTO `client` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', 'BCA', '1', '2016-11-15 09:05:05', '0', '0000-00-00 00:00:00');
INSERT INTO `client` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', 'MANDIRI', '1', '2016-11-15 09:05:10', '0', '0000-00-00 00:00:00');
INSERT INTO `client` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('9', 'MNC', '1', '2016-11-15 09:05:16', '0', '0000-00-00 00:00:00');
INSERT INTO `client` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('10', 'PT AON HEWIT', '1', '2016-12-29 10:20:20', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: crt2
#

DROP TABLE IF EXISTS `crt2`;

CREATE TABLE `crt2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `crt2` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Debit', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `crt2` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Credit', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: invoice
#

DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` int(11) NOT NULL,
  `date_invoice` date NOT NULL,
  `nomor_invoice` varchar(50) NOT NULL,
  `nomor_pe` varchar(50) NOT NULL,
  `nomor_po` varchar(50) NOT NULL,
  `periode` varchar(50) NOT NULL,
  `nomor_faktur` varchar(50) NOT NULL,
  `total` int(11) NOT NULL,
  `total_received` int(11) NOT NULL,
  `date_received` date NOT NULL,
  `note` varchar(200) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `invoice` (`id`, `client`, `date_invoice`, `nomor_invoice`, `nomor_pe`, `nomor_po`, `periode`, `nomor_faktur`, `total`, `total_received`, `date_received`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', '3', '2016-11-18', '001-877-012.02-01-16', '123', '321', 'feb', '030.001-16-05018877', '11745000', '0', '2016-11-18', 'Periode November 2015, total data: 5.267 ER: 992 (30 Okt-30 Nov &amp;#039;15)', '1', '2016-11-18 14:30:04', '1', '2016-11-29 12:42:58');
INSERT INTO `invoice` (`id`, `client`, `date_invoice`, `nomor_invoice`, `nomor_pe`, `nomor_po`, `periode`, `nomor_faktur`, `total`, `total_received`, `date_received`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', '5', '2016-11-29', 'asd', 'asd', 'asd', 'asdads', 'asd', '120000', '0', '2016-11-29', 'asdsdasd', '1', '2016-11-29 13:25:06', '0', '0000-00-00 00:00:00');
INSERT INTO `invoice` (`id`, `client`, `date_invoice`, `nomor_invoice`, `nomor_pe`, `nomor_po`, `periode`, `nomor_faktur`, `total`, `total_received`, `date_received`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', '4', '2016-12-29', '87878', '', '', '787878', '9008888', '7000000', '0', '2016-12-29', '', '1', '2016-12-29 00:10:33', '0', '0000-00-00 00:00:00');
INSERT INTO `invoice` (`id`, `client`, `date_invoice`, `nomor_invoice`, `nomor_pe`, `nomor_po`, `periode`, `nomor_faktur`, `total`, `total_received`, `date_received`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', '3', '2016-12-29', 'asdasd', '', '', 'asdas', 'asdasds', '300000', '0', '2016-12-29', '', '1', '2016-12-29 00:34:48', '1', '2016-12-29 00:35:18');
INSERT INTO `invoice` (`id`, `client`, `date_invoice`, `nomor_invoice`, `nomor_pe`, `nomor_po`, `periode`, `nomor_faktur`, `total`, `total_received`, `date_received`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', '10', '2016-12-29', '011', '', '', '', '', '4500000', '0', '0000-00-00', '', '1', '2016-12-29 10:22:23', '0', '0000-00-00 00:00:00');
INSERT INTO `invoice` (`id`, `client`, `date_invoice`, `nomor_invoice`, `nomor_pe`, `nomor_po`, `periode`, `nomor_faktur`, `total`, `total_received`, `date_received`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', '10', '2016-10-04', '123123213', '', '', '', '', '30000000', '0', '0000-00-00', '', '1', '2016-12-29 10:22:51', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: module
#

DROP TABLE IF EXISTS `module`;

CREATE TABLE `module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `url` varchar(50) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `parent` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `task` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Beranda', 'home', 'fa fa-home', '0', '1', '', '1', '2016-12-15 22:24:48', '1', '2016-12-15 23:23:09');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Data Master', '', 'fa fa-database', '0', '2', '', '1', '2016-12-15 22:25:55', '1', '2016-12-15 23:23:29');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Posting', 'posting', '', '2', '1', 'add,edit,delete,search', '1', '2016-12-15 22:26:25', '1', '2016-12-28 23:19:48');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'Sub Posting', 'postingsub', '', '2', '2', '', '1', '2016-12-15 22:29:31', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'Master Bank', 'bank', '', '2', '3', '', '1', '2016-12-15 22:30:07', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', 'Transaksi', '', 'fa fa-tasks', '0', '3', '', '1', '2016-12-15 22:52:33', '1', '2016-12-15 23:23:53');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', 'Kas Besar', 'big_cash', '', '6', '1', '', '1', '2016-12-15 22:52:57', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', 'Kas Kecil', 'petty_cash', '', '6', '2', '', '1', '2016-12-15 22:53:14', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('9', 'Rekening Koran', 'bank_book', '', '6', '3', '', '1', '2016-12-15 22:53:37', '1', '2016-12-16 01:40:06');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('10', 'Potongan PPH 23', 'pph23', '', '6', '4', '', '1', '2016-12-15 22:55:05', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('11', 'Assets & Maintenance', 'assets', '', '6', '5', '', '1', '2016-12-15 22:55:31', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('12', 'Laporan', 'report', 'fa fa-bar-chart', '0', '4', '', '1', '2016-12-15 23:01:29', '1', '2016-12-16 01:46:06');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('13', 'Kas Besar', 'report/big_cash_report', '', '12', '1', '', '1', '2016-12-15 23:02:01', '1', '2016-12-16 00:14:34');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('14', 'Kas Kecil', 'report/petty_cash_report', '', '12', '2', '', '1', '2016-12-15 23:02:33', '1', '2016-12-16 00:14:53');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('15', 'Rekening Koran/Buku Bank', 'report/bank_book_report', '', '12', '3', '', '1', '2016-12-15 23:03:35', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('16', 'Invoice', 'report/invoice_report', '', '12', '4', '', '1', '2016-12-15 23:04:15', '1', '2016-12-18 08:50:34');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('17', 'Invoice Rekap', 'report/invoice_recap_report', '', '12', '5', '', '1', '2016-12-15 23:05:02', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('18', 'Data Referensi', '', 'fa fa-book', '0', '5', '', '1', '2016-12-15 23:08:11', '1', '2016-12-15 23:24:51');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('19', 'Crt 2', 'reference/crt2', '', '18', '1', '', '1', '2016-12-15 23:08:53', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('20', 'Tipe Kas', 'reference/type_cash', '', '18', '2', '', '1', '2016-12-15 23:10:31', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('21', 'Jenis Biaya', 'reference/biaya', '', '18', '3', '', '1', '2016-12-15 23:11:32', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('22', 'Client', 'reference/client', '', '18', '4', '', '1', '2016-12-15 23:12:00', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('23', 'Level User', 'users_level', '', '18', '5', '', '1', '2016-12-15 23:12:35', '1', '2016-12-16 01:02:56');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('24', 'Status User', 'reference/users_status', '', '18', '6', '', '1', '2016-12-15 23:13:12', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('25', 'Pengguna', 'users', 'fa fa-user', '0', '6', '', '1', '2016-12-15 23:15:54', '1', '2016-12-15 23:25:30');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('26', 'Backup', 'backup', 'fa fa-download', '0', '8', '', '1', '2016-12-15 23:16:42', '1', '2016-12-16 00:21:36');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('27', 'Module', 'module', 'fa fa-check', '0', '7', '', '1', '2016-12-16 00:21:22', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('28', 'Invoice', 'invoice', '', '6', '6', '', '1', '2016-12-18 08:43:06', '0', '0000-00-00 00:00:00');
INSERT INTO `module` (`id`, `name`, `url`, `icon`, `parent`, `order`, `task`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('29', 'Profit and Loss', 'report/profit_and_loss_report', '', '12', '6', '', '1', '2016-12-28 23:45:06', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: petty_cash
#

DROP TABLE IF EXISTS `petty_cash`;

CREATE TABLE `petty_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_entry` date NOT NULL,
  `crt2` int(11) NOT NULL,
  `voucher` int(11) NOT NULL,
  `posting` int(11) NOT NULL,
  `postingsub` int(11) NOT NULL,
  `description` varchar(100) NOT NULL,
  `received` varchar(50) NOT NULL,
  `total` int(11) NOT NULL,
  `note` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `posting` (`posting`),
  KEY `postingsub` (`postingsub`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `petty_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', '2016-12-29', '1', '1', '42', '0', '', '', '5000000', '', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `petty_cash` (`id`, `date_entry`, `crt2`, `voucher`, `posting`, `postingsub`, `description`, `received`, `total`, `note`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', '2016-12-29', '2', '1', '58', '56', '', '', '40000', '', '1', '2016-12-29 09:55:24', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: posting
#

DROP TABLE IF EXISTS `posting`;

CREATE TABLE `posting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `crt2` int(11) NOT NULL,
  `type_cash` int(11) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `crt2` (`crt2`),
  KEY `type_cash` (`type_cash`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Saldo Awal', '1', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Budget Big Cash', '1', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Air', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'Asset', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'Bandung', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', 'Biaya bank', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', 'BPJS Kesehatan', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', 'BPJS Ketenagakerjaan', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('9', 'BRI DE', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('10', 'Client Fee', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('11', 'Donation', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('12', 'Entertain Ext', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('13', 'Entertain Int', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('14', 'HMS Logistic', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('15', 'HMS Moderasi Reguler', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('16', 'HMS Moderasi Beat', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('17', 'HMS Nadyne', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('18', 'HMS Santa Fee', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('19', 'HMS Lain - Lain', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('20', 'insentive', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('21', 'Internet', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('22', 'lembur Driver', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('23', 'Listrik MP V', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('24', 'Listrik MP VIII', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('25', 'maint & equipment', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('26', 'Meal & trans harian', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('27', 'Meal & trans', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('28', 'Pajak', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('29', 'Petty cash', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('30', 'salary pv harian', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('31', 'Salary pv Risaign', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('32', 'salary pv', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('33', 'Salary staff', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('34', 'Salary Auditor & SPV PV', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('35', 'Salary HMS', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('36', 'Salary DE', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('37', 'telp opr Mampang V', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('38', 'telp opr Mampang VIII', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('39', 'telp opr', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('40', 'telp pv', '2', '1', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('41', 'Saldo Awal', '1', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('42', 'Budget Petty cash', '1', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('43', 'Asset', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('44', 'Tunjangan Komunikasi', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('45', 'Cetakan', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('46', 'Donation', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('47', 'Fotocopy', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('48', 'Iklan', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('49', 'Internet', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('50', 'Entertaint ', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('51', 'Iuran Gedung', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('52', 'Lembur / Insentif', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('53', 'Stationary', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('54', 'Off Maint & Equipt', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('55', 'Official', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('56', 'Perlengkapan', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('57', 'Pos & Materai', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('58', 'Transportasi & Parkir', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('59', 'Lain-Lain', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('60', 'Uang Makan', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('61', 'Fee', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('62', 'Niaga Kurir', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('63', 'Legalitas', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('64', 'Print Billing Telp', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('65', 'Sewa PO BOX', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('66', 'Project Mandiri', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `posting` (`id`, `name`, `crt2`, `type_cash`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('67', 'Biaya Bank', '2', '2', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: postingsub
#

DROP TABLE IF EXISTS `postingsub`;

CREATE TABLE `postingsub` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `posting` int(11) NOT NULL,
  `client` int(11) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `biaya` (`client`),
  KEY `posting` (`posting`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Pembayaran client fee ', '10', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Pembayaran marketing fee ', '10', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Pembayaran pajak PPh pasal 21 Karyawan ', '28', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('4', 'Pembayaran pajak PPh pasal 25/ 29 Badan ', '28', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('5', 'Pembayaran pajak pph 23 bukti potong ', '28', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('6', 'Pembayaran pajak PPN', '28', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('7', 'Pembayaran Pajak PBB', '28', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('8', 'Pembayaran Tellephone FO E 1 Kantor Mampang VIII ', '40', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('9', 'Pembayaran Tellephone FO E 1 Kantor Mampang V ', '40', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('10', 'Pembayaran tellephone (Asestama,Dalnet,dll )', '40', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('11', 'Aktiva Tetap', '43', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('12', 'Aktiva Tidak Tetap', '43', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('13', 'Tunjangan Komunikasi Internal', '44', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('14', 'Tunjangan Komunikasi BNI surveyor', '44', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('15', 'Tunjangan Komunikasi Sampoerna', '44', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('16', 'Cetakan Internal', '45', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('17', 'Cetakan Sampoerna', '45', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('18', 'Donation Internal', '46', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('19', 'Donation BNI Surveyor', '46', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('20', 'Fotocopy Internal ', '47', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('21', 'Fotocopy BNI Surveyor', '47', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('22', 'Internet Internal', '49', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('23', 'Internet Sampoerna Verifikasi', '49', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('24', 'Internet Sampoerna moderasi', '49', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('25', 'Entertaint Internal', '50', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('26', 'Entertaint eksternal', '50', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('27', 'Entertaint Bank Mega', '50', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('28', 'Entertaint Bank BRI', '50', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('29', 'Entertaint Sampoerna', '50', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('30', 'Entertaint Mandiri', '50', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('31', 'Entertaint Bank BNI', '50', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('32', 'Lembur / Insentif Internal', '52', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('33', 'Lembur / Insentif Bank Niaga', '52', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('34', 'Lembur / Insentif Bank Mega', '52', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('35', 'Lembur / Insentif Bank BRI', '52', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('36', 'Lembur / Insentif Sampoerna', '52', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('37', 'Lembur / Insentif BNI Surveyor', '52', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('38', 'Stationary Internal', '53', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('39', 'Stationary Bank Niaga', '53', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('40', 'Stationary Bank Mega', '53', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('41', 'Stationary Bank BRI', '53', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('42', 'Stationary Sampoerna', '53', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('43', 'Stationary Fp', '53', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('44', 'Stationary Bank BNI', '53', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('45', 'Stationary Niaga', '53', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('46', 'Off Maint & Equipt Internal', '54', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('47', 'Off Maint & Equipt BRI', '54', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('48', 'Official dapur', '55', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('49', 'Official Air Mineral', '55', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('50', 'Pos & Materai Internal', '57', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('51', 'Pos & Materai Sampoerna', '57', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('52', 'Pos & Materai Fp', '57', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('53', 'Transpotasi & Parkir Internal', '58', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('54', 'Transportasi & Parkir Bank Niaga', '58', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('55', 'Transportasi & Parkir Bank Mega', '58', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('56', 'Transportasi & Parkir Bank BRI', '58', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('57', 'Transportasi & Parkir Samporna', '58', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('58', 'Transportasi & Parkir BPRKS', '58', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('59', 'Transportasi & Parkir Farpoint', '58', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('60', 'Transportasi &amp; Parkir Bank BNI', '58', '3', '0', '0000-00-00 00:00:00', '1', '2016-12-19 12:35:27');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('61', 'Uang Makan Staff PV', '60', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `postingsub` (`id`, `name`, `posting`, `client`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('62', 'Uang Makan Lain-lain', '60', '0', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: pph23
#

DROP TABLE IF EXISTS `pph23`;

CREATE TABLE `pph23` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomor` varchar(50) NOT NULL,
  `client` int(11) NOT NULL,
  `date_faktur` date NOT NULL,
  `total` int(11) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `pph23` (`id`, `nomor`, `client`, `date_faktur`, `total`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', '000023/PPH23/CLN/2016', '3', '2016-11-15', '93914750', '1', '2016-11-15 09:28:26', '0', '0000-00-00 00:00:00');
INSERT INTO `pph23` (`id`, `nomor`, `client`, `date_faktur`, `total`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', '000131/PPH23/CLN/2016', '3', '2016-11-15', '76894750', '1', '2016-11-15 10:06:31', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: type_cash
#

DROP TABLE IF EXISTS `type_cash`;

CREATE TABLE `type_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `type_cash` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Kas Besar', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');
INSERT INTO `type_cash` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Kas Kecil', '0', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` int(11) NOT NULL,
  `ip_login` varchar(50) NOT NULL,
  `date_login` datetime NOT NULL,
  `user_agent` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `users` (`id`, `name`, `username`, `password`, `level`, `ip_login`, `date_login`, `user_agent`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'Adam Prasetia', 'damz', '202cb962ac59075b964b07152d234b70', '1', '::1', '2017-01-01 15:11:57', 'Windows 7(Google Chrome 55.0.2883.87)', '1', '0', '0000-00-00 00:00:00', '2', '2016-10-21 09:34:23');
INSERT INTO `users` (`id`, `name`, `username`, `password`, `level`, `ip_login`, `date_login`, `user_agent`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'Farida Ambarwati', 'ambar', 'caf1a3dfb505ffed0d024130f58c5cfa', '2', '::1', '2016-12-16 01:56:01', 'Windows 7(Google Chrome 55.0.2883.87)', '1', '1', '2016-10-21 09:21:00', '1', '2016-12-16 01:12:10');
INSERT INTO `users` (`id`, `name`, `username`, `password`, `level`, `ip_login`, `date_login`, `user_agent`, `status`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Budiarti', 'adhe', '202cb962ac59075b964b07152d234b70', '3', '::1', '2017-01-01 15:10:28', 'Windows 7(Google Chrome 55.0.2883.87)', '1', '1', '2016-12-30 20:17:58', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: users_level
#

DROP TABLE IF EXISTS `users_level`;

CREATE TABLE `users_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `module` text NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `users_level` (`id`, `name`, `module`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'ADMIN', '1,2,3,4,5,6,7,8,9,10,11,28,12,13,14,15,16,17,29,18,19,20,21,22,23,24,25,27,26', '0', '0000-00-00 00:00:00', '1', '2016-12-28 23:45:33');
INSERT INTO `users_level` (`id`, `name`, `module`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'OPERATOR', '1,2,3,4,5,6,11,12,15', '0', '0000-00-00 00:00:00', '1', '2016-12-16 01:49:02');
INSERT INTO `users_level` (`id`, `name`, `module`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('3', 'Admin 1', '1,2,3,6,8', '1', '2016-12-30 20:16:17', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: users_status
#

DROP TABLE IF EXISTS `users_status`;

CREATE TABLE `users_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_create` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_update` int(11) NOT NULL,
  `date_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `users_status` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('1', 'ACTIVE', '0', '2015-10-31 14:00:03', '1', '2016-06-24 10:43:51');
INSERT INTO `users_status` (`id`, `name`, `user_create`, `date_create`, `user_update`, `date_update`) VALUES ('2', 'NOT ACTIVE', '0', '2015-10-31 14:00:03', '1', '2016-06-24 10:43:55');


